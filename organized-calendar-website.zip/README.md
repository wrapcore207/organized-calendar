# Organized Calendar

Open `index.html` in a browser to use the calendar.

Features:
- Clean organized month calendar
- Add, edit, and delete events
- School / Personal / Sports / Important categories
- Event search
- Date and time
- Notes
- Weekly/monthly repeat field
- Saves events automatically in browser localStorage
- Responsive on phone and desktop

## HTTPS
To put it online with HTTPS, upload this folder to a static host such as GitHub Pages, Netlify, or Cloudflare Pages. These services can provide HTTPS automatically.
